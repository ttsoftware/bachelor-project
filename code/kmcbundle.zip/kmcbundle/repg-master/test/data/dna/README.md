Taken from http://benchmarksgame.alioth.debian.org/u32/performance.php?test=regexdna

See also: https://github.com/BurntSushi/regexp/tree/master/benchmark/regex-dna
