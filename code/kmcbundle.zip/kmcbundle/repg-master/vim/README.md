# Kleenex syntax highlighting for vim

## Installation guide

The easiest way to install this plugin is to use [Vundle](https://github.com/gmarik/Vundle.vim).

If you have Vundle, simply add

    " Syntax highlighting for Kleenex
    Plugin 'diku-kmc/repg', {'rtp': 'vim/'}

to your Vundle bundles in your `.vimrc`, and then perform a `:PluginInstall`.
