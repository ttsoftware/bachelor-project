void printCompilationInfo()
{
  printf("test\n");
}
void match() {}
void init() {}
