#define FLAG_NOMAIN
#include <stdio.h>
FILE *outstream;
#define OUTSTREAM outstream
#include "../crt/crt.c"
#include "dummies.h"
