The KMC Regular Expression Parser
===

![Travis status](https://travis-ci.org/diku-kmc/regexps-syntax.svg?branch=master)

An implementation of a regular expression parser (parsing the
regular expressions themselves, *not* RE parsing on input strings).
